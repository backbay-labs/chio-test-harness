import json, time, shutil, subprocess, sys, hashlib
from pathlib import Path
raw=Path('/tmp/chio-final-delivery-successor-20260910')
cold=Path('/tmp/chio-final-delivery-cold-successor-20260910')
state=Path('/Users/connor/.local/share/chio-required-operators/final-delivery-20260910-r3')
config=Path((raw/'prepare.stdout.txt').read_text().strip())
bridge=raw/'operator-bridge/node_modules/@chio/bridge'
volume='chio-required-final-delivery-20260910-r3'
image='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
commands=[]
def call(name,argv,suffix='txt'):
    start=time.monotonic()
    out=subprocess.run(argv,capture_output=True,timeout=60)
    (raw/(name+'.stdout.'+suffix)).write_bytes(out.stdout)
    (raw/(name+'.stderr.txt')).write_bytes(out.stderr)
    commands.append({'case':name,'command':argv,'exitCode':out.returncode,'durationSeconds':time.monotonic()-start})
    (raw/'operation-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if out.returncode: raise RuntimeError(name+' failed; inspect retained safe logs')
    return out.stdout
observer='const fs=require("node:fs");const f=n=>fs.existsSync("/observe/"+n)?fs.readFileSync("/observe/"+n,"utf8"):null;let audit=fs.existsSync("/audit/dispatch.jsonl")?fs.readFileSync("/audit/dispatch.jsonl","utf8"):"";console.log(JSON.stringify({control:f("delivery-control.txt"),blocked:f("delivery-after-revocation.txt"),audit:audit.split("\\n").filter(Boolean).map(l=>JSON.parse(l))}));'
def observe(name):
    return json.loads(call(name,['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--mount','type=volume,src='+volume+',dst=/observe,readonly','--mount','type=volume,src='+volume+'-audit,dst=/audit,readonly','--entrypoint','node',image,'-e',observer],'json'))
shutil.copyfile('/tmp/chio-final-delivery-operation-20260910/operator-gateway-case.mjs',raw/'operator-gateway-case.mjs')
before=observe('before-control')
call('control',['node',str(raw/'operator-gateway-case.mjs'),str(bridge),str(config),'control',str(raw/'control.json')])
after=observe('after-control')
assert before['control'] is None and before['blocked'] is None
assert after['control']=='delivery observer control\n' and len(after['audit'])==len(before['audit'])+1
snippet=(cold/'README.md').read_text().split("<<'PY'\n",1)[1].split('\nPY\n',1)[0]+'\n'
snippet_path=raw/'documented-revocation.py'; snippet_path.write_text(snippet)
responses=[]
def trace(frame,event,arg):
    if frame.f_code.co_filename==str(snippet_path) and event=='line' and 'result' in frame.f_locals:
        result=frame.f_locals['result']
        if isinstance(result,dict) and result not in responses: responses.append(dict(result))
    return trace
oldargv=sys.argv[:]; start=time.monotonic()
try:
    sys.argv=[str(snippet_path),str(state),str(config)]
    sys.settrace(trace)
    exec(compile(snippet,str(snippet_path),'exec'),{'__name__':'__main__'})
finally:
    sys.settrace(None);sys.argv=oldargv
(raw/'revocation-responses.json').write_text(json.dumps({'responses':responses,'sourceSnippetSha256':hashlib.sha256(snippet.encode()).hexdigest(),'durationSeconds':time.monotonic()-start,'capture':'Unmodified documented snippet executed; Python line tracing copies parsed administrative result dictionaries without changing requests or responses.'},indent=2)+'\n')
assert len(responses)==2 and all(x.get('revoked') is True for x in responses)
call('after-revocation',['node',str(raw/'operator-gateway-case.mjs'),str(bridge),str(config),'after-revocation',str(raw/'after-revocation.json')])
last=observe('after-revocation-observer')
assert last==after
outcome=json.loads((raw/'after-revocation.json').read_text())['outcome']
assert outcome['state']=='not_dispatched'
result={'scope':'Cold successor operator gateway and documented administration procedure, not agent-host acceptance.','passed':True,'kernelSha256':'c03a8a711dbbd15da2c59655d9ab6d8f0068a20187363db7a78f4b5422ded93e','bundleArchiveSha256':'3779a0bdc5f705516a100a2b2ba7dde85debc7eeed0f923eb0839b390e729e55','helperSource':'3374dba0c1537e933e8f3e1074264b96668e5825','helperSha256':'efb4cbde3d032a461d804dc40e2bae32e179219f95ecddf0d112e37cfa14dd6c','controlNewDispatches':len(after['audit'])-len(before['audit']),'postRevocationNewDispatches':len(last['audit'])-len(after['audit']),'forbiddenFileAbsent':last['blocked'] is None,'bothRevocationsBound':True,'ownerStateRetained':str(state),'gatewayConfigRetained':str(config)}
(raw/'operation-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('Successor control verified; both revocations bind; forbidden effect absent and no new dispatch.')
call('owner-stop',['python3',str(cold/'resource-owner/serve-filesystem.py'),'stop','--state-dir',str(state)])
(raw/'owner-stop.json').write_text(json.dumps({'stopped':True,'stateRetained':str(state),'resourceVolumeRetained':volume,'auditVolumeRetained':volume+'-audit'},indent=2)+'\n')
print('Owner stopped; original authority, journals and volumes retained.')
