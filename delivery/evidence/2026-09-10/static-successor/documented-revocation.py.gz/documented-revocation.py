import json
from pathlib import Path
import sys
from urllib.parse import quote
from urllib.request import Request, build_opener, ProxyHandler, HTTPRedirectHandler

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise RuntimeError("operator request must not redirect")

state = Path(sys.argv[1])
operator = json.loads((state / "operator.json").read_text())
execution = json.loads(Path(sys.argv[2]).read_text())["execution"]
origin = "http://127.0.0.1:" + str(operator["port"])
if execution["endpoint"] != origin:
    raise SystemExit("gateway and original resource owner do not match")
session = quote(execution["sessionId"], safe="")
opener = build_opener(ProxyHandler({}), NoRedirect())
for path, body, field, expected in [
    ("/admin/sessions/" + session + "/credential/revoke", {}, "sessionId", execution["sessionId"]),
    ("/admin/revocations", {"capability_id": execution["capabilityId"]}, "capabilityId", execution["capabilityId"]),
]:
    request = Request(origin + path, data=json.dumps(body).encode(), method="POST",
                      headers={"Authorization": "Bearer " + operator["adminToken"],
                               "Content-Type": "application/json"})
    with opener.open(request, timeout=10) as response:
        if response.status != 200:
            raise SystemExit("revocation did not complete; preserve state")
        result = json.load(response)
        if result.get("revoked") is not True or result.get(field) != expected:
            raise SystemExit("revocation response does not bind the original authority")
print("Original session credential and capability revocation requests completed.")
