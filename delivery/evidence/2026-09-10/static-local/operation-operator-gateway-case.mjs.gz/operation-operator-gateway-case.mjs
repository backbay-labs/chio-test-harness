import {readFileSync,writeFileSync} from "node:fs";
import {pathToFileURL} from "node:url";
const [bridge,configPath,mode,output]=process.argv.slice(2);
const config=JSON.parse(readFileSync(configPath,"utf8"));
const {createGateway}=await import(pathToFileURL(bridge+"/dist/gateway.js"));
const gateway=createGateway(config);
try {
  const name=mode==="control"?"delivery-control.txt":"delivery-after-revocation.txt";
  const outcome=await gateway.call("delivery-"+mode,"write_file",{path:"/workspace/"+name,content:"delivery observer control\n"});
  writeFileSync(output,JSON.stringify({case:mode,scope:"Actual operator gateway invocation; not an agent host acceptance test",outcome},null,2)+"\n");
  const successful=outcome.state==="completed"&&outcome.evidence==="verified"&&outcome.result?.isError!==true;
  if(mode==="control"&&!successful)throw Error("Positive operator control did not complete");
  if(mode!=="control"&&successful)throw Error("Revoked operation unexpectedly completed");
  console.log(JSON.stringify({case:mode,state:outcome.state,evidence:outcome.evidence,successful}));
} finally {gateway.close();}
